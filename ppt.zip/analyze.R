setwd("~/University/2013 Fall/36350/project/sim")

# only works if only simulation .Rdata files (nothing else) are in ~/sim
to_load = list.files()
for (i in 1:length(to_load)){
  load(to_load[i])
}

# create a data matrix/frame containing statistics to be analyzed

# 2f_1
chr_2f_1_bw = matrix(data=unlist(sim_chr_2f_1[3,]), ncol=10, byrow=T)
colnames(chr_2f_1_bw) = names(unlist(sim_chr_2f_1[3,]))[1:10]
result_chr_2f_1 = cbind(unlist(sim_chr_2f_1[1,]),
                        chr_2f_1_bw,
                        unlist(sim_chr_2f_1[4,]),
                        unlist(sim_chr_2f_1[5,]))
colnames(result_chr_2f_1)[c(1,12,13)] = c('k', 'mtx_cf', 'pw_cf')
rownames(result_chr_2f_1) = paste('2f_1_', 1:10, sep='')

# 2f_2
chr_2f_2_bw = matrix(data=unlist(sim_chr_2f_2[3,]), ncol=10, byrow=T)
colnames(chr_2f_2_bw) = names(unlist(sim_chr_2f_2[3,]))[1:10]
result_chr_2f_2 = cbind(unlist(sim_chr_2f_2[1,]),
                        chr_2f_2_bw,
                        unlist(sim_chr_2f_2[4,]),
                        unlist(sim_chr_2f_2[5,]))
colnames(result_chr_2f_2)[c(1,12,13)] = c('k', 'mtx_cf', 'pw_cf')
rownames(result_chr_2f_2) = paste('2f_2_', 1:10, sep='')

# 2f_3
chr_2f_3_bw = matrix(data=unlist(sim_chr_2f_3[3,]), ncol=10, byrow=T)
colnames(chr_2f_3_bw) = names(unlist(sim_chr_2f_3[3,]))[1:10]
result_chr_2f_3 = cbind(unlist(sim_chr_2f_3[1,]),
                        chr_2f_3_bw,
                        unlist(sim_chr_2f_3[4,]),
                        unlist(sim_chr_2f_3[5,]))
colnames(result_chr_2f_3)[c(1,12,13)] = c('k', 'mtx_cf', 'pw_cf')
rownames(result_chr_2f_3) = paste('2f_3_', 1:10, sep='')

# m_1
chr_m_1_bw = matrix(data=unlist(sim_chr_m_1[3,]), ncol=10, byrow=T)
colnames(chr_m_1_bw) = names(unlist(sim_chr_m_1[3,]))[1:10]
result_chr_m_1 = cbind(unlist(sim_chr_m_1[1,]),
                        chr_m_1_bw,
                        unlist(sim_chr_m_1[4,]),
                        unlist(sim_chr_m_1[5,]))
colnames(result_chr_m_1)[c(1,12,13)] = c('k', 'mtx_cf', 'pw_cf')
rownames(result_chr_m_1) = paste('m_1_', 1:10, sep='')

# m_2
chr_m_2_bw = matrix(data=unlist(sim_chr_m_2[3,]), ncol=10, byrow=T)
colnames(chr_m_2_bw) = names(unlist(sim_chr_m_2[3,]))[1:10]
result_chr_m_2 = cbind(unlist(sim_chr_m_2[1,]),
                        chr_m_2_bw,
                        unlist(sim_chr_m_2[4,]),
                        unlist(sim_chr_m_2[5,]))
colnames(result_chr_m_2)[c(1,12,13)] = c('k', 'mtx_cf', 'pw_cf')
rownames(result_chr_m_2) = paste('m_2_', 1:10, sep='')

# m_3
chr_m_3_bw = matrix(data=unlist(sim_chr_m_3[3,]), ncol=10, byrow=T)
colnames(chr_m_3_bw) = names(unlist(sim_chr_m_3[3,]))[1:10]
result_chr_m_3 = cbind(unlist(sim_chr_m_3[1,]),
                        chr_m_3_bw,
                        unlist(sim_chr_m_3[4,]),
                        unlist(sim_chr_m_3[5,]))
colnames(result_chr_m_3)[c(1,12,13)] = c('k', 'mtx_cf', 'pw_cf')
rownames(result_chr_m_3) = paste('m_3_', 1:10, sep='')

# bf_1
chr_bf_1_bw = matrix(data=unlist(sim_chr_bf_k1[3,]), ncol=10, byrow=T)
colnames(chr_bf_1_bw) = names(unlist(sim_chr_bf_k1[3,]))[1:10]
result_chr_bf_1 = cbind(unlist(sim_chr_bf_k1[1,]),
                        chr_bf_1_bw,
                        unlist(sim_chr_bf_k1[4,]),
                        unlist(sim_chr_bf_k1[5,]))
colnames(result_chr_bf_1)[c(1,12,13)] = c('k', 'mtx_cf', 'pw_cf')
rownames(result_chr_bf_1) = paste('bf_1_', 1:10, sep='')

# bf_2
chr_bf_2_bw = matrix(data=unlist(sim_chr_bf_k2[3,]), ncol=10, byrow=T)
colnames(chr_bf_2_bw) = names(unlist(sim_chr_bf_k2[3,]))[1:10]
result_chr_bf_2 = cbind(unlist(sim_chr_bf_k2[1,]),
                        chr_bf_2_bw,
                        unlist(sim_chr_bf_k2[4,]),
                        unlist(sim_chr_bf_k2[5,]))
colnames(result_chr_bf_2)[c(1,12,13)] = c('k', 'mtx_cf', 'pw_cf')
rownames(result_chr_bf_2) = paste('bf_2_', 1:10, sep='')

# bf_3
chr_bf_3_bw = matrix(data=unlist(sim_chr_bf_k3[3,]), ncol=10, byrow=T)
colnames(chr_bf_3_bw) = names(unlist(sim_chr_bf_k3[3,]))[1:10]
result_chr_bf_3 = cbind(unlist(sim_chr_bf_k3[1,]),
                        chr_bf_3_bw,
                        unlist(sim_chr_bf_k3[4,]),
                        unlist(sim_chr_bf_k3[5,]))
colnames(result_chr_bf_3)[c(1,12,13)] = c('k', 'mtx_cf', 'pw_cf')
rownames(result_chr_bf_3) = paste('bf_3_', 1:10, sep='')

# r_1
chr_r_1_bw = matrix(data=unlist(sim_chr_r_k1[3,]), ncol=10, byrow=T)
colnames(chr_r_1_bw) = names(unlist(sim_chr_r_k1[3,]))[1:10]
result_chr_r_1 = cbind(unlist(sim_chr_r_k1[1,]),
                        chr_r_1_bw,
                        unlist(sim_chr_r_k1[4,]),
                        unlist(sim_chr_r_k1[5,]))
colnames(result_chr_r_1)[c(1,12,13)] = c('k', 'mtx_cf', 'pw_cf')
rownames(result_chr_r_1) = paste('r_1_', 1:10, sep='')

# r_2
chr_r_2_bw = matrix(data=unlist(sim_chr_r_k2[3,]), ncol=10, byrow=T)
colnames(chr_r_2_bw) = names(unlist(sim_chr_r_k2[3,]))[1:10]
result_chr_r_2 = cbind(unlist(sim_chr_r_k2[1,]),
                        chr_r_2_bw,
                        unlist(sim_chr_r_k2[4,]),
                        unlist(sim_chr_r_k2[5,]))
colnames(result_chr_r_2)[c(1,12,13)] = c('k', 'mtx_cf', 'pw_cf')
rownames(result_chr_r_2) = paste('r_2_', 1:10, sep='')

# r_3
chr_r_3_bw = matrix(data=unlist(sim_chr_r_k3[3,]), ncol=10, byrow=T)
colnames(chr_r_3_bw) = names(unlist(sim_chr_r_k3[3,]))[1:10]
result_chr_r_3 = cbind(unlist(sim_chr_r_k3[1,]),
                        chr_r_3_bw,
                        unlist(sim_chr_r_k3[4,]),
                        unlist(sim_chr_r_k3[5,]))
colnames(result_chr_r_3)[c(1,12,13)] = c('k', 'mtx_cf', 'pw_cf')
rownames(result_chr_r_3) = paste('r_3_', 1:10, sep='') 

# 3f_1
chr_3f_1_bw = matrix(data=unlist(sim_chr_3f_k1[3,]), ncol=10, byrow=T)
colnames(chr_3f_1_bw) = names(unlist(sim_chr_3f_k1[3,]))[1:10]
result_chr_3f_1 = cbind(unlist(sim_chr_3f_k1[1,]),
                       chr_3f_1_bw,
                       unlist(sim_chr_3f_k1[4,]),
                       unlist(sim_chr_3f_k1[5,]))
colnames(result_chr_3f_1)[c(1,12,13)] = c('k', 'mtx_cf', 'pw_cf')
rownames(result_chr_3f_1) = paste('3f_1_', 1:10, sep='') 

# 3f_2
chr_3f_2_bw = matrix(data=unlist(sim_chr_3f_k2[3,]), ncol=10, byrow=T)
colnames(chr_3f_2_bw) = names(unlist(sim_chr_3f_k2[3,]))[1:10]
result_chr_3f_2 = cbind(unlist(sim_chr_3f_k2[1,]),
                        chr_3f_2_bw,
                        unlist(sim_chr_3f_k2[4,]),
                        unlist(sim_chr_3f_k2[5,]))
colnames(result_chr_3f_2)[c(1,12,13)] = c('k', 'mtx_cf', 'pw_cf')
rownames(result_chr_3f_2) = paste('3f_2_', 1:10, sep='') 

# 3f_3
chr_3f_3_bw = matrix(data=unlist(sim_chr_3f_k3[3,]), ncol=10, byrow=T)
colnames(chr_3f_3_bw) = names(unlist(sim_chr_3f_k3[3,]))[1:10]
result_chr_3f_3 = cbind(unlist(sim_chr_3f_k3[1,]),
                        chr_3f_3_bw,
                        unlist(sim_chr_3f_k3[4,]),
                        unlist(sim_chr_3f_k3[5,]))
colnames(result_chr_3f_3)[c(1,12,13)] = c('k', 'mtx_cf', 'pw_cf')
rownames(result_chr_3f_3) = paste('3f_3_', 1:10, sep='') 

chr_half = rbind(result_chr_m_1,  result_chr_m_2,  result_chr_m_3, 
                 result_chr_2f_1, result_chr_2f_2, result_chr_2f_3, 
                 result_chr_3f_1, result_chr_3f_2, result_chr_3f_3, 
                 result_chr_bf_1, result_chr_bf_2, result_chr_bf_3, 
                 result_chr_r_1,  result_chr_r_2,  result_chr_r_3)
chr_half_df = as.data.frame(chr_half)
chr_half_df$chr = rep(c('m', '2f', '3f', 'bf', 'r'), each=30)
chr_half_df$leng = rep(chr_leng[c('M', '2F', '3F', 'BF', 'R')], each=30)
setwd("~/University/2013 Fall/36350/project")
save(chr_half_df, file='chr_half_df.Rdata')
